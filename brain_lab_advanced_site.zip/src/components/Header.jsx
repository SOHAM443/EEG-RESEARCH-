
export default function Header(){
return(
<pre className="ascii">
{`
██████╗ ██████╗  █████╗ ██╗███╗   ██╗
Brain Connectivity Research Lab
Retro Neural Systems Interface
`}
</pre>
)
}
