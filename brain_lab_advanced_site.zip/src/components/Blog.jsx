
const posts=[
{title:"Building Brain Graphs",text:"Exploring EEG connectivity networks."},
{title:"Graph Neural Networks",text:"Using message passing for brain signals."},
{title:"Future Work",text:"Dynamic brain graphs and disease prediction."}
]

export default function Blog(){

return(
<div>

<h2>Research Blog</h2>

{posts.map((p,i)=>(
<div key={i} className="card">
<h3>{p.title}</h3>
<p>{p.text}</p>
</div>
))}

</div>
)

}
