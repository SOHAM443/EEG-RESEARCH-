
import {useState} from "react"

export default function TerminalAI(){

const [log,setLog]=useState([])
const [cmd,setCmd]=useState("")

function run(){

let response="Unknown command"

if(cmd==="help") response="commands: help, train, dataset"
if(cmd==="train") response="Training neural network... accuracy 0.72"
if(cmd==="dataset") response="Loaded OpenNeuro dataset"

setLog([...log,"> "+cmd,response])
setCmd("")

}

return(
<div className="terminal">

{log.map((l,i)=>(<div key={i}>{l}</div>))}

<input
value={cmd}
onChange={e=>setCmd(e.target.value)}
onKeyDown={e=>e.key==="Enter" && run()}
placeholder="type command"
/>

</div>
)

}
