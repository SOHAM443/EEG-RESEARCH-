
const datasets=[
{name:"OpenNeuro",subjects:120,type:"EEG"},
{name:"PhysioNet",subjects:200,type:"EEG Seizure"},
{name:"ABIDE",subjects:500,type:"Autism MRI"},
{name:"ADNI",subjects:800,type:"Alzheimer MRI"}
]

export default function DatasetExplorer(){

return(
<div>
<h2>Dataset Explorer</h2>

{datasets.map((d,i)=>(
<div key={i} className="card">
<b>{d.name}</b>
<div>Subjects: {d.subjects}</div>
<div>Type: {d.type}</div>
</div>
))}

</div>
)

}
