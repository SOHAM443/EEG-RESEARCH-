
import * as d3 from "d3"
import {useEffect,useRef} from "react"

export default function BrainGraph(){

const ref = useRef()

useEffect(()=>{

const width=500
const height=400

const svg=d3.select(ref.current)
.attr("width",width)
.attr("height",height)

const nodes=d3.range(20).map(d=>({id:d}))

const links=d3.range(30).map(()=>({
source:Math.floor(Math.random()*20),
target:Math.floor(Math.random()*20)
}))

const simulation=d3.forceSimulation(nodes)
.force("link",d3.forceLink(links).distance(60))
.force("charge",d3.forceManyBody().strength(-80))
.force("center",d3.forceCenter(width/2,height/2))

const link=svg.selectAll("line")
.data(links)
.enter()
.append("line")
.attr("stroke","#00ffb2")

const node=svg.selectAll("circle")
.data(nodes)
.enter()
.append("circle")
.attr("r",5)
.attr("fill","#00ffb2")

simulation.on("tick",()=>{

link
.attr("x1",d=>d.source.x)
.attr("y1",d=>d.source.y)
.attr("x2",d=>d.target.x)
.attr("y2",d=>d.target.y)

node
.attr("cx",d=>d.x)
.attr("cy",d=>d.y)

})

},[])

return(
<div>
<h2>Brain Connectivity Graph</h2>
<svg ref={ref}></svg>
</div>
)

}
