
import {useEffect,useRef} from "react"
import * as THREE from "three"

export default function Brain3D(){

const mount=useRef()

useEffect(()=>{

const scene=new THREE.Scene()
const camera=new THREE.PerspectiveCamera(75,1,0.1,1000)
const renderer=new THREE.WebGLRenderer()

renderer.setSize(400,400)
mount.current.appendChild(renderer.domElement)

const geometry=new THREE.SphereGeometry(1,32,32)
const material=new THREE.MeshBasicMaterial({wireframe:true,color:0x00ffb2})
const sphere=new THREE.Mesh(geometry,material)

scene.add(sphere)
camera.position.z=3

function animate(){
requestAnimationFrame(animate)
sphere.rotation.y+=0.01
renderer.render(scene,camera)
}

animate()

},[])

return(
<div>
<h2>3D Brain Network</h2>
<div ref={mount}></div>
</div>
)

}
