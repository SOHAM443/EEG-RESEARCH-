
import {useState} from "react"
import Header from "./components/Header"
import BrainGraph from "./components/BrainGraph"
import Brain3D from "./components/Brain3D"
import DatasetExplorer from "./components/DatasetExplorer"
import Blog from "./components/Blog"
import TerminalAI from "./components/TerminalAI"

export default function App(){

const [tab,setTab] = useState("home")

return(
<div className="app">

<Header/>

<div className="nav">
<button onClick={()=>setTab("home")}>HOME</button>
<button onClick={()=>setTab("graph")}>BRAIN GRAPH</button>
<button onClick={()=>setTab("3d")}>3D NETWORK</button>
<button onClick={()=>setTab("data")}>DATASETS</button>
<button onClick={()=>setTab("blog")}>BLOG</button>
<button onClick={()=>setTab("ai")}>AI TERMINAL</button>
</div>

<div className="content">

{tab==="home" &&
<div>
<h2>Brain Connectivity AI Research</h2>
<p>
Exploring brain connectivity graphs using EEG signals and Graph Neural Networks.
</p>
</div>
}

{tab==="graph" && <BrainGraph/>}
{tab==="3d" && <Brain3D/>}
{tab==="data" && <DatasetExplorer/>}
{tab==="blog" && <Blog/>}
{tab==="ai" && <TerminalAI/>}

</div>

</div>
)
}
