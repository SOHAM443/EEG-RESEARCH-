
import { useState } from "react";
import Header from "./components/Header";
import Terminal from "./components/Terminal";
import ResearchLog from "./components/ResearchLog";
import Roadmap from "./pages/Roadmap";

export default function App(){

const [tab,setTab] = useState("home")

return(
<div className="app">

<Header/>

<div className="nav">

<button onClick={()=>setTab("home")}>HOME</button>
<button onClick={()=>setTab("roadmap")}>ROADMAP</button>
<button onClick={()=>setTab("logs")}>RESEARCH LOG</button>
<button onClick={()=>setTab("terminal")}>TERMINAL</button>

</div>

<div className="content">

{tab==="home" && (
<div>

<h2>Brain Connectivity Research</h2>

<p>
Goal: Detect neurological disease patterns using EEG brain connectivity
graphs and Graph Neural Networks.
</p>

<h3>Research Fields</h3>

<ul>
<li>Signal Processing</li>
<li>Graph Theory</li>
<li>Machine Learning</li>
<li>Computational Neuroscience</li>
</ul>

</div>
)}

{tab==="roadmap" && <Roadmap/>}

{tab==="logs" && <ResearchLog/>}

{tab==="terminal" && <Terminal/>}

</div>

</div>
)
}
