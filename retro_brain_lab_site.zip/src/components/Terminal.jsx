
export default function Terminal(){

return(
<div className="terminal">

<div>> load_dataset openneuro</div>
<div>loading eeg dataset...</div>

<div>> construct_graph</div>
<div>nodes: 64</div>
<div>edges: 148</div>

<div>> train_gnn</div>
<div>epoch 1 accuracy: 0.61</div>
<div>epoch 2 accuracy: 0.66</div>
<div>epoch 3 accuracy: 0.70</div>

</div>
)

}
