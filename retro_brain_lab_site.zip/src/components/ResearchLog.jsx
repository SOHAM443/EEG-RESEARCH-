
const logs=[
{date:"2026-04-23",note:"Downloaded OpenNeuro EEG dataset"},
{date:"2026-04-24",note:"Built first brain connectivity graph"},
{date:"2026-04-27",note:"Testing Graph Neural Network baseline"},
{date:"2026-04-30",note:"Experimenting with spectral graph features"}
]

export default function ResearchLog(){

return(
<div>

<h2>Research Logs</h2>

{logs.map((l,i)=>(
<div key={i} className="log">
[{l.date}] {l.note}
</div>
))}

</div>
)

}
