import { useState } from "react";

const phases = [
  {
    id: 1,
    title: "Mathematics Foundation",
    duration: "Month 1–2",
    color: "#00FFB2",
    icon: "∑",
    description: "The mathematical backbone of everything you'll build",
    weeks: [
      {
        week: "Week 1–2",
        topic: "Linear Algebra",
        why: "Brain connectivity matrices, GNN math, eigenvalue decomposition",
        resource: "Gilbert Strang MIT OCW (free)",
        topics: ["Vector spaces & subspaces", "Eigenvalues & eigenvectors", "SVD decomposition", "Graph Laplacian matrix"],
        daily: "2 hours theory + 1 hour problem solving",
      },
      {
        week: "Week 3–4",
        topic: "Probability & Statistics",
        why: "Interpreting brain signal patterns, Bayesian inference on brain data",
        resource: "Harvard Stats 110 — YouTube (free)",
        topics: ["Probability distributions", "Bayesian inference", "Hypothesis testing", "MLE estimation"],
        daily: "2 hours theory + 1 hour problem solving",
      },
      {
        week: "Week 5–6",
        topic: "Signal Processing",
        why: "EEG IS signals — your ECE background covers 60% already",
        resource: "Your ECE coursework + 3Blue1Brown",
        topics: ["Fourier transforms", "Frequency domain analysis", "Band-pass filtering", "Spectral analysis"],
        daily: "2 hours theory + implement filters in Python",
      },
      {
        week: "Week 7–8",
        topic: "Graph Theory + Stochastic Processes",
        why: "Brain is a graph. Disease spreads stochastically through it.",
        resource: "Spielman Yale OCW + MIT 6.262",
        topics: ["Spectral graph theory", "Markov chains", "Random walks on graphs", "Stochastic differential equations (intro)"],
        daily: "2 hours theory + 1 hour implementation",
      },
    ],
  },
  {
    id: 2,
    title: "Neuroscience Basics",
    duration: "Month 2",
    color: "#FF6B6B",
    icon: "🧠",
    description: "Just enough biology — not a medical degree",
    weeks: [
      {
        week: "Week 1",
        topic: "How EEG Works",
        why: "You need to understand what your data actually measures",
        resource: "Neuromatch Academy (free, built for CS/ECE people)",
        topics: ["Neurons and action potentials", "What EEG electrodes measure", "Brain regions and their roles", "Resting state vs task EEG"],
        daily: "1 hour reading + 1 hour MNE Python exploration",
      },
      {
        week: "Week 2",
        topic: "Brain Connectivity & Disease",
        why: "Understanding what changes in disease states",
        resource: "Neuromatch Academy + Google Scholar papers",
        topics: ["Functional connectivity concepts", "How Alzheimer's spreads through brain", "EEG biomarkers of disease", "What theta waves mean clinically"],
        daily: "1 hour reading + 1 hour dataset exploration",
      },
    ],
  },
  {
    id: 3,
    title: "Machine Learning & GNNs",
    duration: "Month 3–4",
    color: "#FFD93D",
    icon: "⚡",
    description: "From classical ML to graph neural networks",
    weeks: [
      {
        week: "Week 1–2",
        topic: "Classical ML Baselines",
        why: "You need baselines to beat — know your enemy",
        resource: "Scikit-learn docs + fast.ai (free)",
        topics: ["Logistic regression on EEG features", "Random forest for brain signals", "SVM for brain state classification", "Feature engineering from EEG"],
        daily: "1 hour theory + 2 hours coding on OpenNeuro data",
      },
      {
        week: "Week 3–4",
        topic: "Deep Learning Foundations",
        why: "GNNs are built on top of these concepts",
        resource: "fast.ai course (free)",
        topics: ["Neural network from scratch in PyTorch", "CNNs for raw EEG signal", "LSTMs for time series brain data", "Backpropagation math"],
        daily: "1 hour theory + 2 hours PyTorch implementation",
      },
      {
        week: "Week 5–8",
        topic: "Graph Neural Networks",
        why: "Your core research tool",
        resource: "Stanford CS224W (free — best GNN course globally)",
        topics: ["Message passing framework", "Graph Convolutional Networks (GCN)", "Graph Attention Networks (GAT)", "Temporal / Dynamic GNNs", "PyTorch Geometric hands-on"],
        daily: "2 hours Stanford lectures + 2 hours implementation",
      },
    ],
  },
  {
    id: 4,
    title: "Brain Data Pipeline",
    duration: "Month 4–5",
    color: "#A8FF78",
    icon: "⚙️",
    description: "Build the full end-to-end system",
    weeks: [
      {
        week: "Week 1",
        topic: "EEG Loading & Preprocessing",
        why: "Raw EEG is noisy — you need clean signals",
        resource: "MNE Python docs",
        topics: ["Load EDF/FIF files with MNE", "Artifact removal (eye blinks, muscle)", "Band-pass filtering", "Epoch extraction"],
        daily: "3 hours coding",
        code: `import mne\nraw = mne.io.read_raw_edf('file.edf', preload=True)\nraw.filter(1., 40.)\nraw.plot()`,
      },
      {
        week: "Week 2",
        topic: "Frequency Band Extraction",
        why: "Each band carries different disease information",
        resource: "MNE Python + SciPy",
        topics: ["Delta (1-4 Hz)", "Theta (4-8 Hz) — Alzheimer's marker", "Alpha (8-13 Hz)", "Beta (13-30 Hz)", "Gamma (30-45 Hz)"],
        daily: "3 hours coding",
        code: `bands = {'theta': (4,8), 'alpha': (8,13)}\nfor band, (lo, hi) in bands.items():\n    filtered = raw.copy().filter(lo, hi)\n    powers[band] = filtered.get_data()`,
      },
      {
        week: "Week 3",
        topic: "Brain Graph Construction",
        why: "Convert signals to graphs for GNN input",
        resource: "NetworkX + PyTorch Geometric",
        topics: ["Correlation matrix = connectivity", "Threshold edges by strength", "Nodes = brain regions", "Build PyG Data objects"],
        daily: "3 hours coding",
        code: `corr = np.corrcoef(eeg_data)\nG = nx.Graph()\nfor i,j in combinations:\n    if corr[i,j] > 0.7:\n        G.add_edge(i, j, weight=corr[i,j])`,
      },
      {
        week: "Week 4–5",
        topic: "Dynamic GNN Training",
        why: "Brain connectivity changes over time — capture that",
        resource: "PyTorch Geometric Temporal",
        topics: ["Temporal graph networks", "Sliding window brain graphs", "Training loop with ADNI/ABIDE data", "Evaluation metrics (AUC, F1)"],
        daily: "3–4 hours coding + experiments",
      },
    ],
  },
  {
    id: 5,
    title: "Research Contribution",
    duration: "Month 5–8",
    color: "#FF9FF3",
    icon: "🔬",
    description: "Find your novel angle and produce results",
    weeks: [
      {
        week: "Month 5",
        topic: "Reproduce a Baseline Paper",
        why: "Understand existing work deeply before improving it",
        resource: "Google Scholar — search 'EEG GNN Alzheimer 2023 2024'",
        topics: ["Find 2-3 papers close to your topic", "Reproduce their results exactly", "Identify what they didn't try", "Document the gap you find"],
        daily: "2 hours paper reading + 2 hours implementation",
      },
      {
        week: "Month 6",
        topic: "Your Novel Contribution",
        why: "This is what makes it YOUR research",
        resource: "Your own implementation",
        topics: ["Add stochastic edge rewiring during disease regime change", "Test if dynamic graphs catch what static models miss", "Ablation study — does each component help?", "Compare vs 3+ baseline methods"],
        daily: "4 hours experiments + documentation",
      },
      {
        week: "Month 7",
        topic: "Rigorous Experiments",
        why: "Good results need solid experimental design",
        resource: "ABIDE + PhysioNet datasets",
        topics: ["Cross-validation properly", "Statistical significance testing", "Multiple datasets for generalization", "Visualize brain graphs — which edges matter?"],
        daily: "4 hours running experiments",
      },
      {
        week: "Month 8",
        topic: "Paper Writing",
        why: "Results without a paper don't exist",
        resource: "Overleaf (free LaTeX)",
        topics: ["Introduction — why this matters", "Related work — what exists", "Method — what you did", "Experiments — what you found", "Target: ICAIF or NeurIPS workshop"],
        daily: "2 hours writing + 2 hours polishing results",
      },
    ],
  },
  {
    id: 6,
    title: "Professor Outreach & Beyond",
    duration: "Month 9–12",
    color: "#74B9FF",
    icon: "🚀",
    description: "Show results, get backing, scale up",
    weeks: [
      {
        week: "Month 9",
        topic: "Approach IIT Professor",
        why: "Now you have results — infinitely more powerful than a cold email",
        resource: "IIT Madras CCBR, IIT Bombay CBN Lab, IISc Brain Computation",
        topics: ["Email with GitHub link + preliminary results", "Ask for 15 min call only", "Get institutional backing for ADNI access", "Potential co-authorship on full paper"],
        daily: "Write outreach emails, prepare results summary",
      },
      {
        week: "Month 10",
        topic: "Paper Submission",
        why: "Get your work timestamped and visible globally",
        resource: "Arxiv (free) + conference submission",
        topics: ["Upload Arxiv preprint immediately", "Submit to ICAIF or NeurIPS Finance/Health workshop", "Share GitHub repo publicly", "LinkedIn post about your research"],
        daily: "Polish paper + submission prep",
      },
      {
        week: "Month 11–12",
        topic: "Scale & Expand",
        why: "One paper opens many doors",
        resource: "Your network + professor connections",
        topics: ["Apply for ADNI premium dataset access", "Extend to new diseases (Parkinson's, epilepsy)", "Consider DST / BIRAC funding application", "Plan next paper or prototype"],
        daily: "Research + networking",
      },
    ],
  },
];

const tools = [
  { name: "MNE Python", use: "EEG signal processing", install: "pip install mne" },
  { name: "PyTorch Geometric", use: "Graph Neural Networks", install: "pip install torch-geometric" },
  { name: "NetworkX", use: "Brain graph construction", install: "pip install networkx" },
  { name: "Nilearn", use: "Neuroimaging ML", install: "pip install nilearn" },
  { name: "SciPy", use: "Signal processing math", install: "pip install scipy" },
  { name: "Scikit-learn", use: "Baseline ML models", install: "pip install scikit-learn" },
];

const datasets = [
  { name: "OpenNeuro", url: "openneuro.org", access: "Free, instant", use: "Start here tomorrow" },
  { name: "PhysioNet", url: "physionet.org", access: "Free, instant", use: "EEG + seizure data" },
  { name: "ABIDE", url: "fcon_1000.projects.nitrc.org", access: "Free after registration", use: "Autism brain imaging" },
  { name: "ADNI", url: "adni.loni.usc.edu", access: "Needs professor backing", use: "Premium Alzheimer's data" },
];

const milestones = [
  { month: "Month 2", achievement: "First EEG visualized + brain graph built", impact: "GitHub post — signal you're serious" },
  { month: "Month 3", achievement: "First working GNN classifier on brain data", impact: "LinkedIn post — rare for undergrad" },
  { month: "Month 4", achievement: "Beat a classical ML baseline", impact: "Approach professor with results" },
  { month: "Month 6", achievement: "Novel contribution implemented", impact: "Arxiv preprint — global visibility" },
  { month: "Month 8", achievement: "Full paper drafted", impact: "Conference submission" },
  { month: "Month 10", achievement: "Paper accepted / under review", impact: "IIT professor collaboration locked in" },
  { month: "Month 12", achievement: "ADNI premium access + next paper planned", impact: "Recognized researcher profile" },
];

export default function Roadmap() {
  const [activePhase, setActivePhase] = useState(0);
  const [activeWeek, setActiveWeek] = useState(0);
  const [activeTab, setActiveTab] = useState("roadmap");

  const phase = phases[activePhase];
  const week = phase?.weeks[activeWeek];

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0A0F",
      color: "#E8E8F0",
      fontFamily: "'Courier New', monospace",
      padding: "0",
    }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #0A0A0F 0%, #111128 100%)",
        borderBottom: "1px solid #222240",
        padding: "24px 32px",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontSize: 11, color: "#00FFB2", letterSpacing: 4, marginBottom: 4 }}>RESEARCH ROADMAP</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: "#fff" }}>Brain GNN · Early Disease Prediction</div>
            <div style={{ fontSize: 12, color: "#666", marginTop: 4 }}>12 Month Plan · ECE + CP + ML + Stochastic Processes</div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {["roadmap", "tools", "data", "milestones"].map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)} style={{
                background: activeTab === tab ? "#00FFB2" : "transparent",
                color: activeTab === tab ? "#000" : "#888",
                border: `1px solid ${activeTab === tab ? "#00FFB2" : "#333"}`,
                padding: "6px 14px",
                borderRadius: 4,
                fontSize: 11,
                letterSpacing: 2,
                cursor: "pointer",
                textTransform: "uppercase",
                fontFamily: "inherit",
                transition: "all 0.2s",
              }}>{tab}</button>
            ))}
          </div>
        </div>
      </div>

      {activeTab === "roadmap" && (
        <div style={{ display: "flex", height: "calc(100vh - 90px)" }}>
          {/* Phase Sidebar */}
          <div style={{
            width: 220,
            background: "#0D0D1A",
            borderRight: "1px solid #1A1A30",
            padding: "20px 0",
            overflowY: "auto",
            flexShrink: 0,
          }}>
            {phases.map((p, i) => (
              <div key={i} onClick={() => { setActivePhase(i); setActiveWeek(0); }}
                style={{
                  padding: "14px 20px",
                  cursor: "pointer",
                  background: activePhase === i ? "#111128" : "transparent",
                  borderLeft: `3px solid ${activePhase === i ? p.color : "transparent"}`,
                  transition: "all 0.2s",
                }}>
                <div style={{ fontSize: 18, marginBottom: 4 }}>{p.icon}</div>
                <div style={{ fontSize: 11, fontWeight: 700, color: activePhase === i ? p.color : "#888", letterSpacing: 1 }}>{p.duration}</div>
                <div style={{ fontSize: 12, color: activePhase === i ? "#fff" : "#555", marginTop: 2, lineHeight: 1.3 }}>{p.title}</div>
              </div>
            ))}
          </div>

          {/* Main Content */}
          <div style={{ flex: 1, overflowY: "auto", padding: "28px 32px" }}>
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 11, color: phase.color, letterSpacing: 3, marginBottom: 8 }}>PHASE {phase.id} · {phase.duration}</div>
              <div style={{ fontSize: 26, fontWeight: 700, color: "#fff", marginBottom: 8 }}>{phase.title}</div>
              <div style={{ fontSize: 13, color: "#777" }}>{phase.description}</div>
            </div>

            {/* Week tabs */}
            <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
              {phase.weeks.map((w, i) => (
                <button key={i} onClick={() => setActiveWeek(i)} style={{
                  background: activeWeek === i ? phase.color : "transparent",
                  color: activeWeek === i ? "#000" : "#666",
                  border: `1px solid ${activeWeek === i ? phase.color : "#333"}`,
                  padding: "6px 14px",
                  borderRadius: 4,
                  fontSize: 11,
                  cursor: "pointer",
                  fontFamily: "inherit",
                  transition: "all 0.2s",
                }}>{w.week}</button>
              ))}
            </div>

            {week && (
              <div style={{ display: "grid", gap: 16 }}>
                {/* Topic card */}
                <div style={{
                  background: "#111128",
                  border: `1px solid ${phase.color}22`,
                  borderRadius: 8,
                  padding: "20px 24px",
                }}>
                  <div style={{ fontSize: 11, color: phase.color, letterSpacing: 2, marginBottom: 8 }}>TOPIC</div>
                  <div style={{ fontSize: 20, fontWeight: 700, color: "#fff", marginBottom: 8 }}>{week.topic}</div>
                  <div style={{ fontSize: 13, color: "#888", marginBottom: 16 }}>
                    <span style={{ color: "#555" }}>Why: </span>{week.why}
                  </div>
                  <div style={{ fontSize: 12, color: "#555" }}>
                    <span style={{ color: "#444" }}>Resource: </span>
                    <span style={{ color: phase.color }}>{week.resource}</span>
                  </div>
                </div>

                {/* Topics to cover */}
                <div style={{
                  background: "#0F0F1E",
                  border: "1px solid #1A1A30",
                  borderRadius: 8,
                  padding: "20px 24px",
                }}>
                  <div style={{ fontSize: 11, color: "#666", letterSpacing: 2, marginBottom: 16 }}>WHAT TO COVER</div>
                  <div style={{ display: "grid", gap: 10 }}>
                    {week.topics.map((t, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                        <div style={{
                          width: 20, height: 20, borderRadius: "50%",
                          background: `${phase.color}22`,
                          border: `1px solid ${phase.color}44`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 9, color: phase.color, flexShrink: 0, marginTop: 1,
                        }}>{i + 1}</div>
                        <div style={{ fontSize: 13, color: "#CCC", lineHeight: 1.5 }}>{t}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Daily schedule */}
                {week.daily && (
                  <div style={{
                    background: "#0F0F1E",
                    border: "1px solid #1A1A30",
                    borderRadius: 8,
                    padding: "16px 24px",
                    display: "flex", alignItems: "center", gap: 12,
                  }}>
                    <div style={{ fontSize: 20 }}>⏱</div>
                    <div>
                      <div style={{ fontSize: 11, color: "#555", letterSpacing: 2, marginBottom: 4 }}>DAILY PLAN</div>
                      <div style={{ fontSize: 13, color: "#aaa" }}>{week.daily}</div>
                    </div>
                  </div>
                )}

                {/* Code snippet */}
                {week.code && (
                  <div style={{
                    background: "#080810",
                    border: "1px solid #1A1A30",
                    borderRadius: 8,
                    padding: "20px 24px",
                  }}>
                    <div style={{ fontSize: 11, color: "#555", letterSpacing: 2, marginBottom: 12 }}>STARTER CODE</div>
                    <pre style={{
                      fontSize: 12,
                      color: "#00FFB2",
                      lineHeight: 1.7,
                      margin: 0,
                      whiteSpace: "pre-wrap",
                    }}>{week.code}</pre>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === "tools" && (
        <div style={{ padding: "32px" }}>
          <div style={{ fontSize: 11, color: "#00FFB2", letterSpacing: 3, marginBottom: 8 }}>TOOLS</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: "#fff", marginBottom: 24 }}>Everything You Need · All Free</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
            {tools.map((t, i) => (
              <div key={i} style={{
                background: "#111128",
                border: "1px solid #1A1A30",
                borderRadius: 8,
                padding: "20px 24px",
              }}>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 6 }}>{t.name}</div>
                <div style={{ fontSize: 12, color: "#777", marginBottom: 16 }}>{t.use}</div>
                <div style={{
                  background: "#080810",
                  borderRadius: 4,
                  padding: "8px 12px",
                  fontSize: 12,
                  color: "#00FFB2",
                  fontFamily: "monospace",
                }}>{t.install}</div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 32 }}>
            <div style={{ fontSize: 11, color: "#666", letterSpacing: 3, marginBottom: 16 }}>WEEKLY SCHEDULE</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 12 }}>
              {[
                { day: "Monday", task: "Math theory", hours: "2 hrs" },
                { day: "Tuesday", task: "Coding", hours: "2 hrs" },
                { day: "Wednesday", task: "Paper reading", hours: "1 hr" },
                { day: "Thursday", task: "Math + Code", hours: "2 hrs" },
                { day: "Friday", task: "Build something", hours: "2 hrs" },
                { day: "Weekend", task: "Review + plan", hours: "1 hr" },
              ].map((d, i) => (
                <div key={i} style={{
                  background: "#111128",
                  border: "1px solid #1A1A30",
                  borderRadius: 8,
                  padding: "16px",
                  textAlign: "center",
                }}>
                  <div style={{ fontSize: 11, color: "#00FFB2", letterSpacing: 1, marginBottom: 8 }}>{d.day.toUpperCase()}</div>
                  <div style={{ fontSize: 12, color: "#ccc", marginBottom: 8 }}>{d.task}</div>
                  <div style={{ fontSize: 20, fontWeight: 700, color: "#fff" }}>{d.hours}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 12, color: "#555", marginTop: 12, textAlign: "center" }}>
              Total: ~10 hours/week · Manageable alongside college
            </div>
          </div>
        </div>
      )}

      {activeTab === "data" && (
        <div style={{ padding: "32px" }}>
          <div style={{ fontSize: 11, color: "#00FFB2", letterSpacing: 3, marginBottom: 8 }}>DATASETS</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: "#fff", marginBottom: 8 }}>Brain Data Sources</div>
          <div style={{ fontSize: 13, color: "#666", marginBottom: 28 }}>
            Strategy: Free data → Build model → Get results → Professor opens premium doors
          </div>

          <div style={{ display: "grid", gap: 16, marginBottom: 32 }}>
            {datasets.map((d, i) => (
              <div key={i} style={{
                background: "#111128",
                border: `1px solid ${i < 2 ? "#00FFB244" : "#1A1A30"}`,
                borderRadius: 8,
                padding: "20px 24px",
                display: "flex",
                alignItems: "center",
                gap: 20,
                flexWrap: "wrap",
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: "50%",
                  background: i < 2 ? "#00FFB222" : "#1A1A30",
                  border: `2px solid ${i < 2 ? "#00FFB2" : "#333"}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 16, fontWeight: 700, color: i < 2 ? "#00FFB2" : "#555",
                  flexShrink: 0,
                }}>{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{d.name}</div>
                  <div style={{ fontSize: 12, color: "#00FFB2", marginBottom: 4 }}>{d.url}</div>
                  <div style={{ fontSize: 12, color: "#888" }}>{d.use}</div>
                </div>
                <div style={{
                  background: i < 2 ? "#00FFB222" : "#1A1A30",
                  border: `1px solid ${i < 2 ? "#00FFB244" : "#333"}`,
                  borderRadius: 4,
                  padding: "6px 12px",
                  fontSize: 11,
                  color: i < 2 ? "#00FFB2" : "#555",
                  letterSpacing: 1,
                  whiteSpace: "nowrap",
                }}>{d.access}</div>
              </div>
            ))}
          </div>

          <div style={{
            background: "#0F0F1E",
            border: "1px solid #1A1A30",
            borderRadius: 8,
            padding: "20px 24px",
          }}>
            <div style={{ fontSize: 11, color: "#666", letterSpacing: 2, marginBottom: 12 }}>START TOMORROW</div>
            <pre style={{ fontSize: 12, color: "#00FFB2", lineHeight: 1.8, margin: 0 }}>
{`# 1. Go to openneuro.org
# 2. Search: "EEG Alzheimer" or "EEG resting state"
# 3. Download any dataset with .edf files
# 4. Run this:

pip install mne numpy matplotlib
python -c "
import mne
raw = mne.io.read_raw_edf('your_file.edf', preload=True)
raw.plot()
print('You are now a brain data researcher.')
"`}
            </pre>
          </div>
        </div>
      )}

      {activeTab === "milestones" && (
        <div style={{ padding: "32px" }}>
          <div style={{ fontSize: 11, color: "#00FFB2", letterSpacing: 3, marginBottom: 8 }}>MILESTONES</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: "#fff", marginBottom: 8 }}>12 Month Profile Building</div>
          <div style={{ fontSize: 13, color: "#666", marginBottom: 32 }}>Each milestone makes the next door easier to open</div>

          <div style={{ position: "relative" }}>
            {/* Timeline line */}
            <div style={{
              position: "absolute",
              left: 19,
              top: 20,
              bottom: 20,
              width: 2,
              background: "linear-gradient(to bottom, #00FFB2, #74B9FF)",
              borderRadius: 2,
            }} />

            <div style={{ display: "grid", gap: 20 }}>
              {milestones.map((m, i) => (
                <div key={i} style={{ display: "flex", gap: 24, alignItems: "flex-start" }}>
                  <div style={{
                    width: 40, height: 40, borderRadius: "50%",
                    background: "#111128",
                    border: `2px solid #00FFB2`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 700, color: "#00FFB2",
                    flexShrink: 0, zIndex: 1,
                  }}>{i + 1}</div>
                  <div style={{
                    background: "#111128",
                    border: "1px solid #1A1A30",
                    borderRadius: 8,
                    padding: "16px 20px",
                    flex: 1,
                  }}>
                    <div style={{ fontSize: 11, color: "#00FFB2", letterSpacing: 2, marginBottom: 6 }}>{m.month.toUpperCase()}</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#fff", marginBottom: 8 }}>{m.achievement}</div>
                    <div style={{ fontSize: 12, color: "#888" }}>
                      <span style={{ color: "#555" }}>Impact: </span>{m.impact}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            marginTop: 32,
            background: "#111128",
            border: "1px solid #00FFB244",
            borderRadius: 8,
            padding: "24px",
            textAlign: "center",
          }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>🎯</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 8 }}>The Profile You'll Have in 12 Months</div>
            <div style={{ fontSize: 13, color: "#888", lineHeight: 1.8 }}>
              Arxiv paper · IIT professor collaboration · GitHub repo with working brain GNN<br />
              ADNI premium dataset access · Rare ECE + ML + Neuro combination globally<br />
              <span style={{ color: "#00FFB2" }}>Zero other 2nd year undergrads doing this.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
